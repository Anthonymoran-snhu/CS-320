package Services;

import Model.Appointment;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }
        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        Appointment appointment = appointments.get(appointmentId);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment ID does not exist");
        }
        return appointment;
    }

    public void updateAppointmentDate(String appointmentId, java.util.Date date) {
        Appointment appointment = getAppointment(appointmentId);
        appointment.setAppointmentDate(date);
    }

    public void updateDescription(String appointmentId, String description) {
        Appointment appointment = getAppointment(appointmentId);
        appointment.setDescription(description);
    }
}