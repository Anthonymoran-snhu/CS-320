package Services;

import Model.Appointment;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    @Test
    void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("1"));
    }

    @Test
    void testAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment));
    }

    @Test
    void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appointment);
        service.deleteAppointment("1");
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment("1"));
    }

    @Test
    void testUpdateDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appointment);
        service.updateDescription("1", "Updated Meeting");
        assertEquals("Updated Meeting", service.getAppointment("1").getDescription());
    }

    @Test
    void testUpdateAppointmentDate() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Date newDate = new Date(System.currentTimeMillis() + 200000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appointment);
        service.updateAppointmentDate("1", newDate);
        assertEquals(newDate, service.getAppointment("1").getAppointmentDate());
    }
}
