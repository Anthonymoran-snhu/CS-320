package Services;

import Model.Task;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    void testAddTask() {
        Task task = new Task("1", "Clean", "Clean the room");
        service.addTask(task);
        assertEquals(task, service.getTask("1"));
    }

    @Test
    void testAddDuplicateTask() {
        Task task = new Task("1", "Clean", "Clean the room");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    @Test
    void testDeleteTask() {
        Task task = new Task("1", "Clean", "Clean the room");
        service.addTask(task);
        service.deleteTask("1");
        assertThrows(IllegalArgumentException.class, () -> service.getTask("1"));
    }

    @Test
    void testUpdateName() {
        Task task = new Task("1", "Clean", "Clean the room");
        service.addTask(task);
        service.updateName("1", "Sweep");
        assertEquals("Sweep", service.getTask("1").getName());
    }

    @Test
    void testUpdateInvalidTask() {
        assertThrows(IllegalArgumentException.class, () -> service.updateName("99", "New Name"));
    }
}