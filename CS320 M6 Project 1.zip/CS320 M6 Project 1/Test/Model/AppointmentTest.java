package Model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentTest {

    @Test
    void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");
        assertEquals("1", appointment.getAppointmentId());
        assertEquals("Meeting", appointment.getDescription());
    }

    @Test
    void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Meeting"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Meeting"));
    }

    @Test
    void testPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", pastDate, "Meeting"));
    }

    @Test
    void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", futureDate, "This description is definitely longer than fifty characters long."));
    }
}
