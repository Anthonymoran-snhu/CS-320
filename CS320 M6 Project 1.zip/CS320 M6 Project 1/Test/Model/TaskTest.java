package Model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("1", "Clean", "Clean the room");
        assertEquals("Clean", task.getName());
        assertEquals("Clean the room", task.getDescription());
    }

    @Test
    void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Clean", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Clean", "Desc"));
    }

    @Test
    void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "NameThatIsWayTooLongForTask", "Desc"));
    }

    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Clean", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Clean", "This description is definitely longer than fifty characters long."));
    }
}